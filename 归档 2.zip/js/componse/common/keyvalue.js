var keyvalue = {
    userinfo: {
        key: "userinfo",
        savetype: "cookies"
    }
}