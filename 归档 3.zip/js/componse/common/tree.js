var tree={
    fenlei_tree:function(id,data){
        
    }
}